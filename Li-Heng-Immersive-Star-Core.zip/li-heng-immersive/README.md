# Li Heng — Personal portfolio

## Five-shape update — 2026-09-21

The immersive version now uses five original bevelled shapes: circle, plus, hollow triangle, hollow square and a slender X. `shapes.js` generates the geometry; `immersive.js` allocates one instanced batch per shape. Total model count remains 180 on initial desktop load and 96 on initial mobile load, including the partial final batch on mobile. Geometry bounds are normalized to a radius of 0.60 before per-instance scaling.

Verified finite geometry, comparable bounds and open centers for the three hollow shapes; desktop and mobile preview initialization; scroll-driven formation; pointer/click interaction; and no browser script errors during the desktop interaction check. This update does not implement the previously discussed physics engine or fix the existing gallery-to-assembly transition. Inter-object collision protection is still pending; the new shapes do not imply a no-penetration guarantee.

A self-contained HTML, CSS and JavaScript portfolio. Open `index.html` in a current desktop browser. No installation or build step is required. All scripts and the original CV are included locally.

## Files

- `index.html` — bilingual content, navigation and page structure
- `styles.css` — responsive layout and palette
- `script.js` — original procedural Three.js sculpture, pointer repulsion, click scatter, scroll camera movement, language switching, journey tabs, copy email and reduced-motion controls
- `assets/Li-Heng-CV.pdf` — original user-supplied CV
- `vendor/` — pinned local third-party libraries

## Design

Terracotta `#98483F`, warm paper `#EEECE6`, charcoal `#292925`. Visual inspiration: Lusion's spatial compositions, generous typography and separation of immersive scenes from editorial content. No Lusion code, images, models, logo or fonts are included. All geometry is generated in JavaScript.

## Content

Education, experience, awards, skills and contacts were adapted from the supplied CV. The planned hackathon pilot is described as planned, not as a completed or proven outcome. Master’s graduation remains expected August 2027. The selected-work area is deliberately empty. The first-person introduction is an editorial synthesis of the CV, not an additional qualification.

Use `data-en` and `data-zh` on text elements to edit both language variants. The romanized name is retained because no Chinese-character name was supplied. The studio's original English name is retained rather than inventing an official translation.

## Interactions and accessibility

- Hover or move over the sculpture to displace the floating rings; click/tap to scatter them.
- Scroll through the hero to move the camera closer and rotate the composition.
- The Experience / Education tabs support arrow keys, Home and End. Experience rows use native disclosure controls.
- The footer can pause motion. The system's reduced-motion preference is respected.
- The scene pauses when outside the viewport or when the browser tab is hidden.
- Small screens use fewer objects and a lower pixel-ratio cap. A static fallback remains if WebGL is unavailable.
- No analytics, forms, cookies, remote API requests or external font loads are included. Email and telephone links open the user's configured applications.

## Dependencies

- Three.js 0.160.1 — MIT. This pinned classic-script build permits opening the page directly with a file URL.
- GSAP / ScrollTrigger 3.13.0 — see the included `vendor/GSAP-README.md` license section and https://gsap.com/standard-license/.

This site has not been published. Publishing would make its included email, phone numbers and downloadable CV publicly accessible.

## Validation

Checked in the local browser preview at desktop size and at a 390px mobile viewport: live WebGL initialization, pointer/click interaction, English/Chinese switching, mobile menu, education/experience tabs with keyboard navigation, disclosure rows, copy email, and motion pause. Checked JavaScript syntax, asset paths, anchor targets and duplicate IDs. The included CV matches the supplied original byte for byte. No script runtime errors were observed. The classic Three.js build emits a non-fatal deprecation notice.

Direct `file://` navigation is blocked by the preview browser's security policy, so double-click opening has not been browser-tested here. The site uses relative classic scripts and local assets with no fetch requests or module imports, to support that use case. The tested local preview is served over HTTP. Cross-browser and physical-device performance testing remain outside this first preview.

2026-09-21: Continuous gallery-to-invitation camera path with gradual model arrival and near-camera frame fading. Four instanced material families (terracotta, ceramic, metal, rubber), 140 desktop / 75 mobile objects; only alternate objects participate in the closing halo. Preserves all five shapes. Gallery and invitation copy shortened in both languages. Validated continuous transition math at three viewport heights and desktop/mobile browser layouts.

2026-09-21 follow-up: Models enlarged 10%; experience cards enlarged responsively. Scene lighting and environment reflection follow blended background luminance. All 140 desktop / 75 mobile objects participate in the final approach, then converge on a torus surface and dissolve into one solid muted-red sculpture.

Mobius update: experience cards enlarged to 440px desktop / 320px mobile, with responsive width caps. Closing sculpture is a half-twist ribbon with rounded thickness, 4096 triangles (previous torus: 6400). Geometry generated once; particle targets use the same parametric surface and orientation. Verified finite positions/normals, closed edges and half-twist seam continuity.

Fragment core: replaces solid ribbon with spaced, asymmetric particle assembly and sparse satellites. Retains five shapes, four material families, smooth approach, subtle whole-core rotation and spring pointer response. Target spacing computed only on initialization; existing instanced rendering retained.
