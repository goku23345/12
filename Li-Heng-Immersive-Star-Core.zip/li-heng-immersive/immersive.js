/* Original scroll-directed scenes. All forms are procedural; no external assets. */
'use strict';
// One continuous scroll coordinate spans the gallery and closing invitation.
window.portfolioEndingState = function(scroll, gallery, assembly) {
  const ease = v => { const t=Math.max(0,Math.min(1,v)); return t*t*(3-2*t); };
  const start=gallery.top+gallery.length*.72;
  const end=assembly.top+assembly.length*.65;
  const approach=ease((scroll-gallery.top)/gallery.length);
  const gather=ease((scroll-start)/(end-start));
  return {gather, appearance:ease((scroll-start)/(end-start)*2.5), z:11-23*approach-10*gather};
};
window.createImmersiveExperience = function ({motion = true} = {}) {
  const $ = s => document.querySelector(s);
  const clamp = (v,a=0,b=1) => Math.max(a,Math.min(b,v));
  const mix = (a,b,t) => a+(b-a)*t;
  const smooth = t => t*t*(3-2*t);
  const story = $('#home'), timeSection = $('#time-travel'), gallerySection = $('#work'), assemblySection = $('#assembly');
  const stage = $('.story-stage');
  const panes = [...document.querySelectorAll('.story-pane')];
  const cards = [...document.querySelectorAll('.time-card')];
  const dots = [...document.querySelectorAll('[data-chapter]')];
  const labels = ['01 / EXPLORATION','02 / PERSPECTIVE','03 / ART','04 / TECHNOLOGY','05 / BUSINESS','06 / LI HENG'];
  let enabled=motion, width=innerWidth, height=innerHeight, mobile=width<700;
  let metrics={}, targetScroll=scrollY, currentScroll=scrollY, last=0, elapsed=0, burst=0;
  let raf=0, renderer=null, scene=null, camera=null, worldGroup=null, galleryGroup=null;
  let shapeBatches=[], particles=[], frames=[], galleryFloor=null, galleryGrid=null;
  let sceneLights=[];
  let pointer={x:0,y:0,active:false}, pointerDown=null;
  let raycaster=null, interactionPlane=null, rayPoint=null;
  let temp=null, colors=null, fog=null, white=null;
  let activeMode='intro', lastChapter=-1, disposed=false;
  const cameraTarget={x:0,y:0,z:12};
  const ranges=[story,timeSection,gallerySection,assemblySection];
  const topOf = el => el.getBoundingClientRect().top + scrollY;
  function refresh() {
    width=innerWidth;height=innerHeight;mobile=width<700;
    metrics={};
    ranges.forEach(el => metrics[el.id]={top:topOf(el),length:Math.max(1,el.offsetHeight-height)});
    targetScroll=scrollY;
    if(renderer){renderer.setSize(width,height,false);camera.aspect=width/height;camera.updateProjectionMatrix();}
    if(!enabled) {panes.forEach(p=>p.setAttribute('aria-hidden','false'));cards.forEach(c=>c.setAttribute('aria-hidden','false'));}
    requestRender();
  }
  const progress = id => clamp((currentScroll-metrics[id].top)/metrics[id].length);
  const intersects = id => currentScroll+height>metrics[id].top && currentScroll<metrics[id].top+metrics[id].length+height;
  function updateChapters(p) {
    const beat=p*5;
    const chapter=Math.min(5,Math.round(beat));
    panes.forEach((pane,i)=>{
      const distance=beat-i;
      const opacity=clamp(1-Math.max(0,Math.abs(distance)-.15)/.39);
      pane.style.opacity=opacity.toFixed(3);
      pane.style.transform=`translate3d(0,${(-distance*65).toFixed(1)}px,0)`;
      pane.classList.toggle('is-active',opacity>.02);
      pane.setAttribute('aria-hidden',opacity<=.02?'true':'false');
    });
    if(chapter!==lastChapter){lastChapter=chapter;$('#chapter-label').textContent=labels[chapter];dots.forEach((d,i)=>{d.classList.toggle('active',i===chapter);d.setAttribute('aria-current',i===chapter?'step':'false');});}
    $('#story-percent').textContent=String(Math.round(p*100)).padStart(3,'0')+'%';
    $('.story-progress>span').style.transform=`scaleX(${p})`;
    stage.classList.toggle('dark-scene',beat>2.45 && beat<4.5);
    story.dataset.chapter=String(chapter);
  }
  function updateTimeline(p) {
    const phase=p*2.5-.25;
    let front=0,closest=10;
    cards.forEach((card,i)=>{
      const d=i-phase;
      if(Math.abs(d)<closest){closest=Math.abs(d);front=i;}
      const opacity=clamp(1-Math.max(0,Math.abs(d)-.6)*.7);
      const x=mobile ? d*135 : d*245;
      const z=-Math.abs(d)*420;
      const y=Math.abs(d)*35;
      card.style.transform=`translate3d(${x.toFixed(1)}px,${y.toFixed(1)}px,${z.toFixed(1)}px) rotateY(${(-d*24+pointer.x*4).toFixed(1)}deg) rotateX(${(-pointer.y*3).toFixed(1)}deg)`;
      card.style.opacity=opacity.toFixed(3);card.style.zIndex=String(10-Math.round(Math.abs(d)*3));
      card.setAttribute('aria-hidden',Math.abs(d)>1.7?'true':'false');
    });
    $('.timeline-year').textContent=front===0?'2023':'2024';
    $('.timeline-year').style.transform=`translateX(${-p*12}%)`;
    $('#time-index').textContent=`0${front+1} / 03`;
    timeSection.dataset.moment=String(front+1);
  }

  function initWorld() {
    if(!window.THREE) return;
    const T=THREE;
    try {renderer=new T.WebGLRenderer({canvas:$('#world-canvas'),antialias:true,powerPreference:'high-performance'});}catch(_){return;}
    renderer.setPixelRatio(Math.min(devicePixelRatio,mobile?1.3:1.6));
    renderer.outputColorSpace=T.SRGBColorSpace;
    renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=.95;
    scene=new T.Scene();scene.background=new T.Color(0xeeece6);
    fog=new T.Fog(0xeeece6,26,78);scene.fog=fog;
    camera=new T.PerspectiveCamera(44,width/height,.1,110);camera.position.z=12;
    const ambient=new T.HemisphereLight(0xfff4e6,0x605450,2.5);scene.add(ambient);
    const light=new T.DirectionalLight(0xfff3e7,4.1);light.position.set(-5,8,7);scene.add(light);
    const edge=new T.DirectionalLight(0xffffff,3.2);edge.position.set(7,3,-3);scene.add(edge);
    const fill=new T.DirectionalLight(0xcbaa9e,1.4);fill.position.set(-7,-3,0);scene.add(fill);
    sceneLights=[ambient,light,edge,fill].map(light=>({light,base:light.intensity}));
    const room=new T.Scene();room.background=new T.Color(0xc4bbae);
    const pg=new T.PlaneGeometry(15,10),pm=new T.MeshBasicMaterial({color:0xffffff,side:T.DoubleSide});
    [[0,7,0,-Math.PI/2,0],[-8,2,0,0,Math.PI/2],[4,1,7,0,0]].forEach(p=>{const m=new T.Mesh(pg,pm);m.position.set(...p.slice(0,3));m.rotation.set(p[3],p[4],0);room.add(m);});
    const gen=new T.PMREMGenerator(renderer), env=gen.fromScene(room,.025,.1,50);
    scene.environment=env.texture;gen.dispose();pg.dispose();pm.dispose();
    worldGroup=new T.Group();scene.add(worldGroup);
    const n=mobile?75:140;
    const finishes=[
      {name:'terracotta',color:0x98483f,material:new T.MeshPhysicalMaterial({roughness:.88,metalness:0,clearcoat:0})},
      {name:'ceramic',color:0xeee7d9,material:new T.MeshPhysicalMaterial({roughness:.2,metalness:0,clearcoat:.95,clearcoatRoughness:.12})},
      {name:'brushed-metal',color:0xb5a99a,material:new T.MeshPhysicalMaterial({roughness:.3,metalness:.96,envMapIntensity:1.15})},
      {name:'rubber',color:0x363735,material:new T.MeshPhysicalMaterial({roughness:.98,metalness:0,clearcoat:0,envMapIntensity:.25})}
    ];
    const shapeSet=window.createPortfolioShapeSet(T);
    const assignments=Array.from({length:n},(_,i)=>i%5*4+Math.floor(i/5)%4);
    shapeBatches=shapeSet.flatMap(({name,geometry},type)=>finishes.map((finish,f)=>{
      const count=assignments.filter(key=>key===type*4+f).length;
      const mesh=new T.InstancedMesh(geometry,finish.material,count);
      mesh.name=name+'-'+finish.name;
      mesh.instanceMatrix.setUsage(T.DynamicDrawUsage);
      mesh.frustumCulled=false;
      worldGroup.add(mesh);
      return mesh;
    }));
    $('#world').dataset.shapes=shapeSet.map(shape=>shape.name).join(',');
    $('#world').dataset.shapeCounts=shapeBatches.map(mesh=>mesh.count).join(',');
    $('#world').dataset.materials=finishes.map(f=>f.name).join(',');
    $('#world').dataset.particleCount=String(n);
    const instanceCounts=shapeBatches.map(()=>0);
    const random=i=>{const v=Math.sin(i*127.1+51.7)*43758.5453;return v-Math.floor(v);};
    const corePoints=[];
    for(let i=0;i<n;i++){
      const a=i*2.399963,r=4.7+random(i)*6,z=-random(i+4)*28;
      const field=[Math.cos(a)*r*1.35,Math.sin(a)*r*.9,z];
      const tunnel=[Math.cos(a)*(4+random(i)*1.8),Math.sin(a)*(3.6+random(i)*1.6),-i*.42];
      const t=i/n*Math.PI*2;
      const art=[(2+Math.cos(3*t))*Math.cos(2*t)*1.12,(2+Math.cos(3*t))*Math.sin(2*t)*1.12,Math.sin(3*t)*1.1];
      const side=mobile?0:3.1, up=mobile?2.0:0;
      art[0]+=side;art[1]+=up;art[2]-=40;
      const cols=mobile?6:8,rows=mobile?4:5;
      const grid=[((i%cols)-(cols-1)/2)*.85+side,(Math.floor(i/cols)%rows-(rows-1)/2)*.85+up,-40-Math.floor(i/(cols*rows))*1.1];
      const yy=1-2*(i+.5)/n,rr=Math.sqrt(1-yy*yy);
      const sphere=[Math.cos(a)*rr*3.0+side,yy*3+up,Math.sin(a)*rr*3-40];
      const final=[Math.cos(a)*(3.8+random(i)*1.5),Math.sin(a)*(3.8+random(i)*1.5),-42+random(i)*4];
      // Spaced, asymmetric fragments: a denser core and a few orbiting outliers.
      const unit=mobile?.66:1, size=.45+random(i+5)*.75;
      let core;
      for(let attempt=0;attempt<1600;attempt++){
        const seed=i*1709+attempt*7,az=random(seed+101)*Math.PI*2;
        const vertical=random(seed+102)*2-1,radial=Math.sqrt(1-vertical*vertical);
        const radius=i%13===0?2.85:Math.cbrt(.3+random(seed+103)*11.8);
        const yy=vertical*radius;
        core=[Math.cos(az)*radial*radius*.88+yy*.24,yy*1.08,Math.sin(az)*radial*radius*.8];
        if(corePoints.every(p=>Math.hypot(core[0]-p.x,core[1]-p.y,core[2]-p.z)>.6*.46*(size+p.size)+.06))break;
      }
      corePoints.push({x:core[0],y:core[1],z:core[2],size});
      const assembly=[core[0]*unit+(mobile?0:4.3),core[1]*unit+(mobile?2:0),-36+core[2]*unit];
      const batch=assignments[i],instance=instanceCounts[batch]++;
      particles.push({batch,instance,poses:[field,tunnel,art,grid,sphere,final],assembly,scale:.45+random(i+5)*.75,ox:0,oy:0,vx:0,vy:0,rx:random(i+8)*6,ry:random(i+9)*6});
      shapeBatches[batch].setColorAt(instance,new T.Color(finishes[Math.floor(i/5)%4].color));
    }
    shapeBatches.forEach(mesh=>mesh.instanceColor.needsUpdate=true);
    temp=new T.Object3D();raycaster=new T.Raycaster();interactionPlane=new T.Plane();rayPoint=new T.Vector3();
    colors=[0xeeece6,0xe5e0d5,0xeeece6,0x252724,0x813e36,0xeeece6].map(c=>new T.Color(c));
    white=new T.Color(0xeeece6);
    // An actual 3D gallery: open frames occupy successively deeper positions.
    galleryGroup=new T.Group();scene.add(galleryGroup);
    const frameMaterial=new T.MeshStandardMaterial({color:0x773a31,roughness:.4,metalness:.28});
    const wallMaterial=new T.MeshStandardMaterial({color:0xddd7c9,roughness:.9});
    for(let i=0;i<3;i++){
      const frame=new T.Group(), fw=mobile?3.7:5,fh=4.5;
      const frameFinish=frameMaterial.clone();frameFinish.transparent=true;
      [[0,fh/2,fw+.16,.14],[0,-fh/2,fw+.16,.14],[-fw/2,0,.14,fh],[fw/2,0,.14,fh]].forEach(([x,y,w,h])=>{const bar=new T.Mesh(new T.BoxGeometry(w,h,.25),frameFinish);bar.position.set(x,y,0);frame.add(bar);});
      const labelCanvas=document.createElement('canvas');labelCanvas.width=512;labelCanvas.height=128;const ctx=labelCanvas.getContext('2d');
      ctx.fillStyle='#6e6258';ctx.font='24px Arial';ctx.fillText(`0${i+1} / SPACE RESERVED`,22,50);ctx.font='13px Arial';ctx.fillText('THE NEXT CHAPTER IS STILL UNWRITTEN.',22,85);
      const labelTexture=new T.CanvasTexture(labelCanvas);labelTexture.colorSpace=T.SRGBColorSpace;
      const label=new T.Mesh(new T.PlaneGeometry(2.6,.65),new T.MeshBasicMaterial({map:labelTexture,transparent:true,depthWrite:false}));label.position.set(-fw/2+1.15,-fh/2-.55,.05);frame.add(label);
      frame.position.set((i%2===0?1:-1)*(mobile?.3:1.9),.4,-i*9);galleryGroup.add(frame);frames.push(frame);
    }
    const floor=new T.Mesh(new T.PlaneGeometry(80,110),wallMaterial);floor.rotation.x=-Math.PI/2;floor.position.set(0,-3.1,-30);galleryGroup.add(floor);
    const grid=new T.GridHelper(100,50,0xb4a99b,0xcac2b5);grid.position.set(0,-3.08,-30);grid.material.transparent=true;grid.material.opacity=.32;galleryGroup.add(grid);
    galleryFloor=floor;galleryGrid=grid;wallMaterial.transparent=true;
    galleryGroup.visible=false;
    document.body.classList.add('world-ready');$('#world').dataset.sceneStatus='ready';
    const canvas=$('#world-canvas');
    canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();cancelAnimationFrame(raf);document.body.classList.remove('world-ready');$('#world').dataset.sceneStatus='lost';});
    canvas.addEventListener('webglcontextrestored',()=>{document.body.classList.add('world-ready');$('#world').dataset.sceneStatus='ready';requestRender();});
  }

  function drawParticles(beat,dt,assemblyP=null) {
    const T=THREE;
    const a=Math.min(4,Math.floor(beat)),b=a+1, blend=smooth(clamp(beat-a));
    const step=dt*60;
    const assemblyMode=assemblyP!==null;
    if(!assemblyMode) {
      scene.background.copy(colors[a]).lerp(colors[b],blend);
      cameraTarget.z=beat<1?mix(12,4,smooth(beat)):beat<2?mix(4,-28,smooth(beat-1)):-28;
      cameraTarget.x=beat<2?Math.sin(beat*Math.PI)*.6:0;
      cameraTarget.y=beat<2?Math.sin(beat*Math.PI*1.5)*.35:0;
    }
    if(!assemblyMode){
    fog.color.copy(scene.background);fog.near=25;fog.far=80;
    camera.position.set(cameraTarget.x+pointer.x*.24,cameraTarget.y+pointer.y*.15,cameraTarget.z);
    camera.rotation.set(-pointer.y*.012,-pointer.x*.014,0);
    worldGroup.visible=true;galleryGroup.visible=false;
    }
    // Match actual linear background luminance, including the blended intermediate colors.
    const bg=scene.background,luminance=bg.r*.2126+bg.g*.7152+bg.b*.0722;
    const illumination=mix(.2,1,clamp(luminance/.84));
    sceneLights.forEach(({light,base})=>light.intensity=base*illumination);
    shapeBatches.forEach(mesh=>{
      if(mesh.material.userData.baseEnv===undefined)mesh.material.userData.baseEnv=mesh.material.envMapIntensity;
      mesh.material.envMapIntensity=mesh.material.userData.baseEnv*illumination;
    });
    $('#world').dataset.illumination=illumination.toFixed(3);
    raycaster.setFromCamera(pointer,camera);
    interactionPlane.set(new T.Vector3(0,0,1),-(camera.position.z-12));
    const hit=raycaster.ray.intersectPlane(interactionPlane,rayPoint);
    particles.forEach((s,i)=>{
      let x,y,z;
      if(assemblyMode){const q=assemblyP.gather;x=mix(s.poses[0][0]*.65,s.assembly[0],q);y=mix(s.poses[0][1]*.65,s.assembly[1],q);z=mix(-43-i%7,s.assembly[2],q);}
      else{x=mix(s.poses[a][0],s.poses[b][0],blend);y=mix(s.poses[a][1],s.poses[b][1],blend);z=mix(s.poses[a][2],s.poses[b][2],blend);}
      if(assemblyMode){
        const turn=Math.sin(elapsed*.19)*.16*assemblyP.gather;
        const cx=mobile?0:4.3,dx=x-cx,dz=z+36;
        x=cx+dx*Math.cos(turn)+dz*Math.sin(turn);z=-36-dx*Math.sin(turn)+dz*Math.cos(turn);
      }
      if(!assemblyMode && beat>1.8 && beat<4.7){
        const pivotX=mobile?0:3.1, pivotY=mobile?2:0;
        const turn=(Math.sin(elapsed*.2)*.23+pointer.x*.08)*clamp((beat-1.8)*5)*clamp((4.7-beat)*5);
        const xx=x-pivotX,zz=z+40;
        x=pivotX+xx*Math.cos(turn)+zz*Math.sin(turn);
        z=-40-xx*Math.sin(turn)+zz*Math.cos(turn);
        y=pivotY+(y-pivotY);
      }
      const float=assemblyMode?.035:(beat>1.6?.035:.16);
      x+=Math.sin(elapsed*.35+i)*float;y+=Math.cos(elapsed*.4+i)*float;
      const dx=x+s.ox-(hit?rayPoint.x:0),dy=y+s.oy-(hit?rayPoint.y:0),dist=Math.max(.1,Math.hypot(dx,dy));
      const force=pointer.active&&hit?Math.max(0,1-dist/2.6)*.065:0;
      s.vx=(s.vx+(dx/dist*force-s.ox*.009)*step)*Math.pow(.88,step);
      s.vy=(s.vy+(dy/dist*force-s.oy*.009)*step)*Math.pow(.88,step);
      s.ox=clamp(s.ox+s.vx*step,-4,4);s.oy=clamp(s.oy+s.vy*step,-4,4);
      const scatter=burst*(.8+Math.sin(i)*.2);
      const freedom=assemblyMode?.55:1;
      temp.position.set(x+(s.ox+Math.cos(i)*scatter)*freedom,y+(s.oy+Math.sin(i)*scatter)*freedom,z);
      temp.rotation.set(s.rx+elapsed*.09,s.ry+elapsed*.12,Math.sin(elapsed*.15+i)*.5);
      let scale=s.scale*1.1*(beat<1.3?1:mix(1,.65,clamp(beat-1.3)));
      if(assemblyMode) scale=s.scale*.46*(mobile?.8:1)*assemblyP.appearance;
      temp.scale.setScalar(scale);temp.updateMatrix();
      shapeBatches[s.batch].setMatrixAt(s.instance,temp.matrix);
    });
    shapeBatches.forEach(mesh=>mesh.instanceMatrix.needsUpdate=true);
    $('#world').dataset.cameraDepth=camera.position.z.toFixed(1);
  }
  function drawGallery(p,dt) {
    const ending=window.portfolioEndingState(currentScroll,metrics.work,metrics.assembly);
    worldGroup.visible=false;galleryGroup.visible=true;scene.background.copy(white);fog.color.copy(white);fog.near=18;fog.far=55;
    camera.position.set(Math.sin(p*Math.PI*2)*(mobile?.45:1.1)+pointer.x*.35,.4+pointer.y*.2,ending.z);
    camera.rotation.set(-pointer.y*.012,-pointer.x*.025,Math.sin(p*Math.PI)*.015);
    frames.forEach((frame,i)=>{frame.rotation.y=Math.sin(elapsed*.22+i)*.045+pointer.x*.04;frame.rotation.z=Math.sin(elapsed*.17+i)*.025;
      const opacity=smooth(clamp((camera.position.z-frame.position.z-.6)/3.5));
      frame.children.forEach(child=>{child.material.opacity=opacity;child.material.depthWrite=opacity>.95;});
    });
    const floorOpacity=1-smooth(clamp((ending.gather-.4)/.6));
    galleryFloor.material.opacity=floorOpacity;galleryFloor.material.depthWrite=floorOpacity>.95;
    galleryGrid.material.opacity=.32*floorOpacity;
    $('#gallery-index').textContent=`ROOM 0${Math.min(3,Math.floor(p*3)+1)} / 03`;
    $('#world').dataset.cameraDepth=camera.position.z.toFixed(1);
    gallerySection.dataset.room=String(Math.min(3,Math.floor(p*3)+1));
    worldGroup.visible=ending.appearance>0;
    drawParticles(0,dt,ending);
    $('#world').dataset.endingProgress=ending.gather.toFixed(4);
  }
  function render(now) {
    raf=0;if(disposed)return;
    const dt=last?Math.min((now-last)/1000,.04):1/60;last=now;
    targetScroll=scrollY;currentScroll=enabled?mix(currentScroll,targetScroll,1-Math.exp(-dt*13)):targetScroll;
    elapsed+=enabled?dt:0;burst*=Math.pow(.94,dt*60);
    if(enabled){
      if(intersects('home')){activeMode='intro';updateChapters(progress('home'));}
      else if(intersects('work'))activeMode='gallery';
      else if(intersects('assembly'))activeMode='assembly';
      else activeMode='reading';
      if(intersects('time-travel'))updateTimeline(progress('time-travel'));
      if(renderer && activeMode!=='reading'){
        if(activeMode==='gallery'||activeMode==='assembly')drawGallery(progress('work'),dt);
        else drawParticles(progress('home')*5,dt);
        renderer.render(scene,camera);
      }
    }
    $('#world').dataset.mode=activeMode;
    if(enabled&&!document.hidden)raf=requestAnimationFrame(render);
  }
  function requestRender(){if(!raf&&!document.hidden)raf=requestAnimationFrame(render);}
  try{initWorld();}catch(error){console.warn('3D scene unavailable. Reading mode is available.',error);}
  // If WebGL is unavailable, avoid an empty 3D tour and retain all real content.
  if(!renderer){document.body.classList.add('motion-off');enabled=false;$('#world').dataset.sceneStatus='fallback';}
  refresh();
  window.addEventListener('scroll',()=>{targetScroll=scrollY;requestRender();},{passive:true});
  let resizeTimer;
  window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(refresh,140);});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(raf);raf=0;last=0;}else requestRender();});
  if(window.ScrollTrigger)ScrollTrigger.addEventListener('refresh',refresh);
  dots.forEach(dot=>dot.addEventListener('click',()=>{
    const target=metrics.home.top+metrics.home.length*(Number(dot.dataset.chapter)/5);
    window.scrollTo({top:target,behavior:enabled?'smooth':'auto'});
  }));
  document.addEventListener('pointermove',e=>{pointer.x=e.clientX/width*2-1;pointer.y=-(e.clientY/height)*2+1;pointer.active=true;},{passive:true});
  document.addEventListener('pointerleave',()=>{pointer.active=false;pointer.x=0;pointer.y=0;});
  document.addEventListener('pointerdown',e=>{pointerDown={x:e.clientX,y:e.clientY};});
  document.addEventListener('pointerup',e=>{
    if(pointerDown && Math.hypot(e.clientX-pointerDown.x,e.clientY-pointerDown.y)<8 && !e.target.closest('a,button,summary') && enabled)burst=2;
    pointerDown=null;if(e.pointerType==='touch')pointer.active=false;
  });
  // Subtle pointer attraction on actual action links, independent of scene controls.
  document.querySelectorAll('.contact-pill,.cv-button,.round-arrow').forEach(el=>{
    el.addEventListener('pointermove',e=>{if(!enabled||e.pointerType==='touch')return;const r=el.getBoundingClientRect();el.style.transform=`translate(${(e.clientX-r.left-r.width/2)*.15}px,${(e.clientY-r.top-r.height/2)*.2}px)`;});
    el.addEventListener('pointerleave',()=>el.style.transform='');
  });
  if(window.gsap&&window.ScrollTrigger){
    gsap.registerPlugin(ScrollTrigger);
    const mm=gsap.matchMedia();
    mm.add('(prefers-reduced-motion: no-preference)',()=>{
      gsap.to('.about-heading',{xPercent:-3,ease:'none',scrollTrigger:{trigger:'#about',start:'top bottom',end:'bottom top',scrub:1}});
      gsap.fromTo('.skills h2',{y:45},{y:-25,ease:'none',scrollTrigger:{trigger:'#skills',start:'top bottom',end:'bottom top',scrub:1}});
      gsap.fromTo('.contact-title',{xPercent:-4},{xPercent:0,ease:'none',scrollTrigger:{trigger:'#contact',start:'top bottom',end:'top 15%',scrub:1}});
    });
  }
  return {setMotion(value){enabled=value&&!!renderer;document.body.classList.toggle('motion-off',!enabled);pointer.active=false;last=0;currentScroll=scrollY;refresh();requestRender();},refresh};
};
