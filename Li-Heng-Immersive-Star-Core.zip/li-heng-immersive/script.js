/* Li Heng — personal portfolio. All dependencies are local; no build step. */
(() => {
  'use strict';
  const $ = (selector) => document.querySelector(selector);
  const motionPreference = window.matchMedia('(prefers-reduced-motion: reduce)');
  let motionOff = motionPreference.matches;
  let language = 'en';
  let sceneController = null;
  let animationContext = null;
  let toastTimer;

  function toast(text) {
    const el = $('.toast');
    el.textContent = text;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
  }

  function updateMotionLabel() {
    const button = $('#motion-toggle');
    button.setAttribute('aria-pressed', String(motionOff));
    button.querySelector('span').textContent = language === 'zh'
      ? (motionOff ? '动效已暂停' : '动效已开启')
      : (motionOff ? 'Motion paused' : 'Motion on');
    document.body.classList.toggle('motion-off', motionOff);
    $('#quick-motion').textContent = motionOff ? '▷' : 'Ⅱ';
    $('#quick-motion').setAttribute('aria-pressed', String(motionOff));
    $('#quick-motion').setAttribute('aria-label', motionOff ? 'Resume motion' : 'Pause motion');
  }

  function setupPageMotion() {
    if (!window.gsap || !window.ScrollTrigger) return;
    if (animationContext) animationContext.revert();
    if (motionOff) return;
    gsap.registerPlugin(ScrollTrigger);
    animationContext = gsap.context(() => {
      document.querySelectorAll('.reveal').forEach(el => {
        gsap.from(el, {
          y: 35, opacity: 0, duration: .9, ease: 'power2.out',
          scrollTrigger: {trigger: el, start: 'top 93%', once: true}
        });
      });
      gsap.to('.about-mark', {
        rotation: 22, ease: 'none',
        scrollTrigger: {trigger: '.about', start: 'top bottom', end: 'bottom top', scrub: 1}
      });
    });
  }

  $('#language').addEventListener('click', () => {
    language = language === 'en' ? 'zh' : 'en';
    document.documentElement.lang = language === 'zh' ? 'zh-CN' : 'en';
    document.querySelectorAll('[data-en][data-zh]').forEach(el => {
      el.textContent = el.dataset[language].replace(/\\n/g, '\n');
    });
    $('#language').textContent = language === 'en' ? '中文' : 'EN';
    $('#language').setAttribute('aria-label', language === 'en' ? 'Switch to Chinese' : '切换为英文');
    updateMotionLabel();
    if (window.ScrollTrigger) ScrollTrigger.refresh();
  });

  function setMotion(off) {
    motionOff = off;
    updateMotionLabel();
    setupPageMotion();
    if (sceneController) sceneController.setMotion(!off);
  }
  $('#motion-toggle').addEventListener('click', () => setMotion(!motionOff));
  motionPreference.addEventListener('change', e => setMotion(e.matches));

  const menuToggle = $('.menu-toggle');
  const mobileMenu = $('#mobile-menu');
  function closeMenu() {
    mobileMenu.hidden = true;
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.setAttribute('aria-label', 'Open menu');
  }
  menuToggle.addEventListener('click', () => {
    const opening = mobileMenu.hidden;
    mobileMenu.hidden = !opening;
    menuToggle.setAttribute('aria-expanded', String(opening));
    menuToggle.setAttribute('aria-label', opening ? 'Close menu' : 'Open menu');
  });
  mobileMenu.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMenu));
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && !mobileMenu.hidden) {closeMenu(); menuToggle.focus();}
  });

  const tabs = [...document.querySelectorAll('[role=tab]')];
  function selectTab(tab) {
    tabs.forEach(item => {
      const active = item === tab;
      item.setAttribute('aria-selected', String(active));
      item.tabIndex = active ? 0 : -1;
      document.getElementById(item.dataset.panel).hidden = !active;
    });
    if (window.ScrollTrigger) ScrollTrigger.refresh();
  }
  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => selectTab(tab));
    tab.addEventListener('keydown', e => {
      let next;
      if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') next = tabs[1 - index];
      if (e.key === 'Home') next = tabs[0];
      if (e.key === 'End') next = tabs[tabs.length - 1];
      if (next) {e.preventDefault(); selectTab(next); next.focus();}
    });
  });
  document.querySelectorAll('details').forEach(el => el.addEventListener('toggle', () => {
    if (window.ScrollTrigger) ScrollTrigger.refresh();
  }));

  $('#copy-email').addEventListener('click', async () => {
    const email = 'L1943144500@163.com';
    let copied = false;
    try {await navigator.clipboard.writeText(email); copied = true;} catch (_) {
      const textarea = document.createElement('textarea');
      textarea.value = email;
      textarea.style.cssText = 'position:fixed;left:-9999px;top:0';
      document.body.append(textarea);
      textarea.select();
      try {copied = document.execCommand('copy');} catch (_) { /* Manual fallback below. */ }
      textarea.remove();
      $('#copy-email').focus();
    }
    toast(copied ? (language === 'zh' ? '邮箱已复制' : 'Email copied to clipboard') : email);
  });

  updateMotionLabel();
  sceneController = window.createImmersiveExperience({motion: !motionOff});
  $('#quick-motion').addEventListener('click', () => setMotion(!motionOff));
  setupPageMotion();
})();
