/* Five original, bevelled symbols, normalized to the same visual envelope. */
window.createPortfolioShapeSet = function (T) {
  const outline = points => {
    const path = new T.Shape();
    path.moveTo(...points[0]);
    points.slice(1).forEach(point => path.lineTo(...point));
    path.closePath();
    return path;
  };
  const extrude = (shape, depth=.25, bevel=.035) => {
    const geometry = new T.ExtrudeGeometry(shape, {
      depth, bevelEnabled:true, bevelSegments:3, steps:1,
      bevelSize:bevel, bevelThickness:bevel, curveSegments:8
    });
    geometry.center();
    return geometry;
  };
  const crossOutline = (arm,halfWidth) => outline([
    [-halfWidth,-arm],[halfWidth,-arm],[halfWidth,-halfWidth],
    [arm,-halfWidth],[arm,halfWidth],[halfWidth,halfWidth],
    [halfWidth,arm],[-halfWidth,arm],[-halfWidth,halfWidth],
    [-arm,halfWidth],[-arm,-halfWidth],[-halfWidth,-halfWidth]
  ]);
  const triangle = outline([[0,.60],[-.52,-.30],[.52,-.30]]);
  triangle.holes.push(outline([[0,.29],[.25,-.145],[-.25,-.145]]));
  const square = outline([[-.47,-.47],[.47,-.47],[.47,.47],[-.47,.47]]);
  square.holes.push(outline([[-.27,-.27],[-.27,.27],[.27,.27],[.27,-.27]]));
  const x = extrude(crossOutline(.64,.105),.21,.035);
  x.rotateZ(Math.PI/4);
  const shapes = [
    {name:'circle', geometry:new T.TorusGeometry(.43,.155,12,28)},
    {name:'plus', geometry:extrude(crossOutline(.48,.15),.28,.055)},
    {name:'triangle', geometry:extrude(triangle)},
    {name:'square', geometry:extrude(square)},
    {name:'x', geometry:x}
  ];
  shapes.forEach(({geometry}) => {
    geometry.computeBoundingSphere();
    const radius=geometry.boundingSphere.radius;
    geometry.scale(.60/radius,.60/radius,.60/radius);
    geometry.computeBoundingBox();
    geometry.computeBoundingSphere();
  });
  return shapes;
};
