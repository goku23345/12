/* Li Heng — personal portfolio. All dependencies are local; no build step. */
(() => {
  'use strict';
  const $ = (selector) => document.querySelector(selector);
  const motionPreference = window.matchMedia('(prefers-reduced-motion: reduce)');
  let motionOff = motionPreference.matches;
  let language = 'en';
  let sceneController = null;
  let animationContext = null;
  let toastTimer;

  function toast(text) {
    const el = $('.toast');
    el.textContent = text;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
  }

  function updateMotionLabel() {
    const button = $('#motion-toggle');
    button.setAttribute('aria-pressed', String(motionOff));
    button.querySelector('span').textContent = language === 'zh'
      ? (motionOff ? '动效已暂停' : '动效已开启')
      : (motionOff ? 'Motion paused' : 'Motion on');
    document.body.classList.toggle('motion-off', motionOff);
  }

  function setupPageMotion() {
    if (!window.gsap || !window.ScrollTrigger) return;
    if (animationContext) animationContext.revert();
    if (motionOff) return;
    gsap.registerPlugin(ScrollTrigger);
    animationContext = gsap.context(() => {
      document.querySelectorAll('.reveal').forEach(el => {
        gsap.from(el, {
          y: 35, opacity: 0, duration: .9, ease: 'power2.out',
          scrollTrigger: {trigger: el, start: 'top 93%', once: true}
        });
      });
      gsap.to('.about-mark', {
        rotation: 22, ease: 'none',
        scrollTrigger: {trigger: '.about', start: 'top bottom', end: 'bottom top', scrub: 1}
      });
    });
  }

  $('#language').addEventListener('click', () => {
    language = language === 'en' ? 'zh' : 'en';
    document.documentElement.lang = language === 'zh' ? 'zh-CN' : 'en';
    document.querySelectorAll('[data-en][data-zh]').forEach(el => {
      el.textContent = el.dataset[language].replace(/\\n/g, '\n');
    });
    $('#language').textContent = language === 'en' ? '中文' : 'EN';
    $('#language').setAttribute('aria-label', language === 'en' ? 'Switch to Chinese' : '切换为英文');
    updateMotionLabel();
    if (window.ScrollTrigger) ScrollTrigger.refresh();
  });

  function setMotion(off) {
    motionOff = off;
    updateMotionLabel();
    setupPageMotion();
    if (sceneController) sceneController.setMotion(!off);
  }
  $('#motion-toggle').addEventListener('click', () => setMotion(!motionOff));
  motionPreference.addEventListener('change', e => setMotion(e.matches));

  const menuToggle = $('.menu-toggle');
  const mobileMenu = $('#mobile-menu');
  function closeMenu() {
    mobileMenu.hidden = true;
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.setAttribute('aria-label', 'Open menu');
  }
  menuToggle.addEventListener('click', () => {
    const opening = mobileMenu.hidden;
    mobileMenu.hidden = !opening;
    menuToggle.setAttribute('aria-expanded', String(opening));
    menuToggle.setAttribute('aria-label', opening ? 'Close menu' : 'Open menu');
  });
  mobileMenu.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMenu));
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && !mobileMenu.hidden) {closeMenu(); menuToggle.focus();}
  });

  const tabs = [...document.querySelectorAll('[role=tab]')];
  function selectTab(tab) {
    tabs.forEach(item => {
      const active = item === tab;
      item.setAttribute('aria-selected', String(active));
      item.tabIndex = active ? 0 : -1;
      document.getElementById(item.dataset.panel).hidden = !active;
    });
    if (window.ScrollTrigger) ScrollTrigger.refresh();
  }
  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => selectTab(tab));
    tab.addEventListener('keydown', e => {
      let next;
      if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') next = tabs[1 - index];
      if (e.key === 'Home') next = tabs[0];
      if (e.key === 'End') next = tabs[tabs.length - 1];
      if (next) {e.preventDefault(); selectTab(next); next.focus();}
    });
  });
  document.querySelectorAll('details').forEach(el => el.addEventListener('toggle', () => {
    if (window.ScrollTrigger) ScrollTrigger.refresh();
  }));

  $('#copy-email').addEventListener('click', async () => {
    const email = 'L1943144500@163.com';
    let copied = false;
    try {await navigator.clipboard.writeText(email); copied = true;} catch (_) {
      const textarea = document.createElement('textarea');
      textarea.value = email;
      textarea.style.cssText = 'position:fixed;left:-9999px;top:0';
      document.body.append(textarea);
      textarea.select();
      try {copied = document.execCommand('copy');} catch (_) { /* Manual fallback below. */ }
      textarea.remove();
      $('#copy-email').focus();
    }
    toast(copied ? (language === 'zh' ? '邮箱已复制' : 'Email copied to clipboard') : email);
  });

  function initScene() {
    if (!window.THREE) return null;
    const T = window.THREE;
    const wrap = $('#scene-wrap');
    const canvas = $('#hero-canvas');
    let renderer;
    try {
      renderer = new T.WebGLRenderer({canvas, alpha: true, antialias: true, powerPreference: 'high-performance'});
    } catch (_) {
      wrap.setAttribute('aria-label', 'Terracotta sculptural forms. Static rendering.');
      $('.scene-caption').textContent = 'FIG. 01 / FORMS IN DIALOGUE';
      return null;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, window.innerWidth < 700 ? 1.5 : 1.8));
    renderer.outputColorSpace = T.SRGBColorSpace;
    renderer.toneMapping = T.ACESFilmicToneMapping;
    renderer.toneMappingExposure = .95;
    const scene = new T.Scene();
    const camera = new T.PerspectiveCamera(36, 1, .1, 60);
    camera.position.set(0, .1, 11.8);
    scene.add(new T.HemisphereLight(0xfff9ed, 0x67594c, 2.8));
    const keyLight = new T.DirectionalLight(0xfff5eb, 4.2);
    keyLight.position.set(-4, 7, 6);
    scene.add(keyLight);
    const rim = new T.DirectionalLight(0xffffff, 3.5);
    rim.position.set(5, 3, -3);
    scene.add(rim);
    const fill = new T.DirectionalLight(0xd2b8ac, .9);
    fill.position.set(-5, -2, 1);
    scene.add(fill);

    // A procedural studio environment: no downloaded imagery or models.
    const envScene = new T.Scene();
    envScene.background = new T.Color(0xafa295);
    const panelGeo = new T.PlaneGeometry(12, 8);
    const panelMat = new T.MeshBasicMaterial({color: 0xffffff, side: T.DoubleSide});
    [[0,5,0,-Math.PI/2,0],[-6,1,0,0,Math.PI/2],[3,1,5,0,0]].forEach(p => {
      const panel = new T.Mesh(panelGeo, panelMat);
      panel.position.set(p[0],p[1],p[2]); panel.rotation.set(p[3],p[4],0); envScene.add(panel);
    });
    const pmrem = new T.PMREMGenerator(renderer);
    const environment = pmrem.fromScene(envScene, .025, .1, 40);
    scene.environment = environment.texture;
    pmrem.dispose(); panelGeo.dispose(); panelMat.dispose();

    const red = new T.MeshPhysicalMaterial({color:0x71362f, roughness:.38, metalness:.18, clearcoat:.4, clearcoatRoughness:.35, envMapIntensity:.65});
    const sculpture = new T.Group();
    scene.add(sculpture);
    const knotGeometry = new T.TorusKnotGeometry(1.64, .52, 180, 28, 2, 3);
    const knot = new T.Mesh(knotGeometry, red);
    knot.rotation.set(.3, -.45, .6);
    sculpture.add(knot);
    sculpture.position.set(.3, .2, 0);

    const satelliteGeometry = new T.TorusGeometry(.37, .115, 12, 32);
    const satelliteMaterial = new T.MeshStandardMaterial({roughness:.38, metalness:.16, envMapIntensity:.8});
    const count = window.innerWidth < 700 ? 11 : 19;
    const satellites = new T.InstancedMesh(satelliteGeometry, satelliteMaterial, count);
    satellites.instanceMatrix.setUsage(T.DynamicDrawUsage);
    satellites.frustumCulled = false;
    scene.add(satellites);
    const helper = new T.Object3D();
    const states = [];
    const colors = [0x98483f, 0xb86b59, 0xd2cbbd, 0x635e54, 0xe5dccd];
    for (let i = 0; i < count; i++) {
      const angle = i * 2.39996;
      const radius = 2.55 + (i % 4) * .3;
      states.push({
        x: Math.cos(angle) * radius, y: Math.sin(angle) * radius * .82,
        z: -1.4 + (i % 5) * .48,
        scale: .34 + (i % 4) * .2,
        rx: i * .74, ry: i * .49, rz: i * .18,
        ox: 0, oy: 0, vx: 0, vy: 0
      });
      satellites.setColorAt(i, new T.Color(colors[i % colors.length]));
    }
    satellites.instanceColor.needsUpdate = true;

    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = shadowCanvas.height = 128;
    const shadowContext = shadowCanvas.getContext('2d');
    const gradient = shadowContext.createRadialGradient(64,64,3,64,64,64);
    gradient.addColorStop(0,'rgba(64,42,29,0.24)');
    gradient.addColorStop(.4,'rgba(64,42,29,0.11)');
    gradient.addColorStop(1,'rgba(64,42,29,0)');
    shadowContext.fillStyle = gradient; shadowContext.fillRect(0,0,128,128);
    const shadowTexture = new T.CanvasTexture(shadowCanvas);
    const shadow = new T.Mesh(new T.PlaneGeometry(6,2.2), new T.MeshBasicMaterial({map:shadowTexture,transparent:true,depthWrite:false}));
    shadow.position.set(.3,-2.8,-1.5);
    scene.add(shadow);

    const pointer = new T.Vector2(0,0);
    let pointerActive = false;
    let visible = true;
    let enabled = !motionOff;
    let elapsed = 0;
    let lastTime = 0;
    let scrollProgress = 0;
    let blast = 0;
    let rect = wrap.getBoundingClientRect();
    const hero = $('#home');
    let heroHeight = hero.offsetHeight;
    function resize() {
      rect = wrap.getBoundingClientRect();
      const width = wrap.clientWidth, height = wrap.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width,height,false);
      heroHeight = hero.offsetHeight;
      if (!enabled || !visible) draw(0);
    }
    function readScroll() {
      scrollProgress = Math.min(Math.max(window.scrollY / heroHeight,0),1);
      rect = wrap.getBoundingClientRect();
    }
    window.addEventListener('scroll', readScroll, {passive:true});
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(wrap);
    const intersectionObserver = new IntersectionObserver(entries => {
      visible = entries[0].isIntersecting;
      updateLoop();
    }, {rootMargin:'80px'});
    intersectionObserver.observe(hero);
    document.addEventListener('visibilitychange', updateLoop);
    function updatePointer(e) {
      pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      pointerActive = true;
    }
    wrap.addEventListener('pointermove', updatePointer, {passive:true});
    wrap.addEventListener('pointerleave', () => {pointerActive=false; pointer.set(0,0);});
    let down = null;
    wrap.addEventListener('pointerdown', e => {updatePointer(e); down = {x:e.clientX,y:e.clientY};});
    wrap.addEventListener('pointerup', e => {
      if (down && Math.hypot(e.clientX-down.x,e.clientY-down.y) < 9 && enabled) {
        blast = 1;
        states.forEach(s => {s.vx += s.x * .05; s.vy += s.y * .05;});
      }
      down = null;
      if (e.pointerType === 'touch') {pointerActive=false; pointer.set(0,0);}
    });

    function draw(now) {
      const delta = lastTime ? Math.min((now-lastTime)/1000,.05) : 1/60;
      lastTime = now;
      const step = delta * 60;
      if (enabled) elapsed += delta;
      blast *= Math.pow(.95,step);
      const progress = enabled ? scrollProgress : 0;
      camera.position.z = 11.8 - progress * 2.1;
      camera.position.x += ((enabled ? pointer.x*.25 : 0) - camera.position.x) * .04;
      sculpture.rotation.y = -.25 + elapsed * .075 + progress * .8;
      sculpture.rotation.z = -.15 + Math.sin(elapsed*.24)*.075 + progress*.25;
      sculpture.rotation.x = enabled ? pointer.y*.1 : 0;
      sculpture.position.y = .2 + Math.sin(elapsed*.6)*.09 + progress*.5;
      const pulse = 1 + blast*.04;
      sculpture.scale.setScalar(pulse);
      const px = pointer.x * 4.1 * camera.aspect;
      const py = pointer.y * 4.1;
      states.forEach((s,i) => {
        const baseX = s.x + Math.sin(elapsed*.26+i)*.12;
        const baseY = s.y + Math.cos(elapsed*.3+i)*.14;
        const dx = baseX+s.ox-px, dy = baseY+s.oy-py;
        const distance = Math.max(Math.hypot(dx,dy),.1);
        const force = pointerActive && enabled ? Math.max(0,1-distance/1.9)*.014 : 0;
        s.vx = (s.vx + (dx/distance*force-s.ox*.005)*step)*Math.pow(.91,step);
        s.vy = (s.vy + (dy/distance*force-s.oy*.005)*step)*Math.pow(.91,step);
        s.ox += s.vx*step; s.oy += s.vy*step;
        const spread = 1 + progress*.24;
        helper.position.set((baseX+s.ox)*spread, (baseY+s.oy)*spread,s.z);
        helper.rotation.set(s.rx+elapsed*.13,s.ry+elapsed*.18,s.rz+elapsed*.09);
        helper.scale.setScalar(s.scale);
        helper.updateMatrix();
        satellites.setMatrixAt(i,helper.matrix);
      });
      satellites.instanceMatrix.needsUpdate = true;
      renderer.render(scene,camera);
    }
    function updateLoop() {
      lastTime = 0;
      renderer.setAnimationLoop(enabled && visible && !document.hidden ? draw : null);
    }
    resize(); draw(0); updateLoop();
    wrap.classList.add('scene-ready');
    wrap.dataset.sceneStatus = 'ready';
    canvas.addEventListener('webglcontextlost', e => {
      e.preventDefault(); renderer.setAnimationLoop(null);
      wrap.classList.remove('scene-ready');
      wrap.dataset.sceneStatus = 'fallback';
      $('.scene-caption').textContent = 'FIG. 01 / FORMS IN DIALOGUE';
    });
    canvas.addEventListener('webglcontextrestored', () => {
      wrap.classList.add('scene-ready');wrap.dataset.sceneStatus='ready';draw(0);updateLoop();
    });
    return {setMotion(value) {enabled=value; pointerActive=false;pointer.set(0,0);draw(0);updateLoop();}};
  }

  updateMotionLabel();
  try {sceneController = initScene();} catch (error) {
    $('#scene-wrap').dataset.sceneStatus = 'fallback';
    console.warn('The interactive sculpture could not start; displaying the static composition.', error);
    $('.scene-caption').textContent = 'FIG. 01 / FORMS IN DIALOGUE';
  }
  setupPageMotion();
})();
