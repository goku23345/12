/* The original Blender GLBs, loaded with the official r160 GLTFLoader. */
window.createPortfolioCharacters = function(camera) {
  const T=THREE, group=new T.Group();
  camera.add(group); group.visible=false;
  const files=['01_triangle.glb','02_circle.glb','03_square.glb','04_x.glb','05_plus.glb'];
  const friends=[], local=new T.Vector3(), projected=new T.Vector3();
  const raycaster=new T.Raycaster();
  let ready=false, failed=false, load=0, targets=[], reveal=0, gather=0;
  let grabbed=null; // the friend currently being dragged
  Promise.all(files.map(file=>new Promise((resolve,reject)=>{
    const encoded=window.portfolioCharacterGLBs?.[file];
    if(!encoded) return reject(new Error('Missing character: '+file));
    const buffer=Uint8Array.from(atob(encoded),c=>c.charCodeAt(0)).buffer;
    new T.GLTFLoader().parse(buffer,'',gltf=>resolve(gltf.scene),reject);
  }))).then(models=>{
    models.forEach((model,i)=>{
      const box=new T.Box3().setFromObject(model), size=box.getSize(new T.Vector3());
      const center=box.getCenter(new T.Vector3());
      const holder=new T.Group(), scale=1.8/size.y;
      model.position.copy(center).multiplyScalar(-scale); model.scale.setScalar(scale);
      const materials=[], meshes=[];
      model.traverse(o=>{
        if(o.isMesh){
          o.material=o.material.clone();o.material.transparent=true;materials.push(o.material);
          o.userData.friendIndex=i; meshes.push(o);
        }
      });
      holder.add(model); group.add(holder);
      friends.push({holder,materials,meshes,ox:0,oy:0,vx:0,vy:0,
        rx:0,ry:0,vrx:0,vry:0,prevRx:0,prevRy:0,grabbed:false});
    });
    ready=true;document.querySelector('#world').dataset.characters='ready';
    delete window.portfolioCharacterGLBs;
  }).catch(error=>{
    failed=true;document.querySelector('#world').dataset.characters='fallback';
    console.warn('Character models unavailable; original ending retained.',error);
  });
  const clamp=v=>Math.max(0,Math.min(1,v));
  const ease=v=>{v=clamp(v);return v*v*(3-2*v);};
  function update(p,dt,time,pointer,width,height){
    if(!ready||failed){group.visible=false;return;}
    load=Math.min(1,load+dt*1.5);
    const mobile=width<=700;
    gather=ease((p+.20)/.52)*ease(load);
    reveal=ease((p-.18)/.44)*ease(load);
    group.visible=reveal>.001;
    const depth=16-6*ease((p+.05)/.7);
    const vh=2*Math.tan(T.MathUtils.degToRad(camera.fov/2))*depth, vw=vh*camera.aspect;
    const anchors=mobile?[[-.63,-.06],[0,-.04],[.63,-.06],[-.32,-.54],[.32,-.54]]:
      [[.14,.30],[.47,.32],[.80,.28],[.30,-.33],[.67,-.33]];
    const unit=mobile?Math.min(vw*.23,vh*.185)/1.8:Math.min(vw*.135,vh*.235)/1.8;
    camera.updateMatrixWorld(true);
    targets=[];
    friends.forEach((f,i)=>{
      const a=anchors[i], bounce=reveal*Math.max(0,Math.sin(time*2.5+i*1.2))*vh*.018;
      const x=a[0]*vw/2, y=a[1]*vh/2+bounce;
      // Screen-space distance makes repulsion agree with the visible cursor.
      local.set(x+f.ox,y+f.oy,-depth); projected.copy(local).applyMatrix4(camera.matrixWorld).project(camera);
      let dx=(projected.x-pointer.x)*width/2,dy=(projected.y-pointer.y)*height/2;
      const distance=Math.hypot(dx,dy), radius=Math.min(width,height)*.19;
      if(distance<1){dx=i%2?1:-1;dy=.3;}
      // A grabbed figure stays put while being dragged; the others still breathe.
      const force=(pointer.active&&!f.grabbed)?Math.max(0,1-distance/radius)*reveal:0;
      const targetX=dx/Math.max(1,distance)*force*unit*.34;
      const targetY=dy/Math.max(1,distance)*force*unit*.34;
      f.vx+=(targetX-f.ox)*38*dt;f.vy+=(targetY-f.oy)*38*dt;
      f.vx*=Math.exp(-9*dt);f.vy*=Math.exp(-9*dt);
      f.ox=Math.max(-unit*.4,Math.min(unit*.4,f.ox+f.vx*dt));
      f.oy=Math.max(-unit*.4,Math.min(unit*.4,f.oy+f.vy*dt));
      f.holder.position.set(x+f.ox,y+f.oy,-depth);

      // Per-figure user rotation: idle bob + user drag offset.
      if(!f.grabbed){
        // Inertia after release, then slow spring back to neutral.
        f.rx+=f.vrx*dt; f.ry+=f.vry*dt;
        f.vrx*=Math.exp(-3.2*dt); f.vry*=Math.exp(-3.2*dt);
        const spring=Math.exp(-0.7*dt);
        f.rx*=spring; f.ry*=spring;
      }
      f.vrx=(f.rx-f.prevRx)/Math.max(dt,1e-4);
      f.vry=(f.ry-f.prevRy)/Math.max(dt,1e-4);
      f.prevRx=f.rx; f.prevRy=f.ry;
      f.rx=Math.max(-0.5,Math.min(0.5,f.rx));
      f.holder.rotation.set(
        Math.sin(time*1.2+i)*.045*reveal + f.rx,
        Math.sin(time*.9+i)*.10*reveal + f.ry,
        Math.sin(time*1.4+i)*.07*reveal);
      f.holder.scale.setScalar(unit*(.65+.35*reveal));
      f.materials.forEach(m=>{m.opacity=reveal;m.depthWrite=reveal>.98;});
      targets.push(local.set(x,y,-depth).applyMatrix4(camera.matrixWorld).clone());
    });
    document.querySelector('#world').dataset.characterReveal=reveal.toFixed(3);
  }
  // Original procedural shape order: circle, plus, triangle, square, X.
  const shapeToFriend=[1,4,0,2,3];

  // --- Per-figure drag rotation (option A: inertia + slow ease-back) ---
  function tryGrab(ndcX, ndcY){
    if(!ready||failed||reveal<0.9||grabbed) return false;
    raycaster.setFromCamera({x:ndcX,y:ndcY}, camera);
    const allMeshes=[];
    friends.forEach(f=>allMeshes.push(...f.meshes));
    const hits=raycaster.intersectObjects(allMeshes, false);
    if(!hits.length) return false;
    const idx=hits[0].object.userData.friendIndex;
    if(idx===undefined) return false;
    grabbed=friends[idx]; grabbed.grabbed=true;
    grabbed.prevRx=grabbed.rx; grabbed.prevRy=grabbed.ry;
    grabbed.vrx=0; grabbed.vry=0;
    return true;
  }
  function dragBy(dxPx, dyPx){
    if(!grabbed) return;
    grabbed.ry+=dxPx*0.006;
    grabbed.rx+=dyPx*0.006;
  }
  function releaseGrab(){
    if(!grabbed) return;
    grabbed.grabbed=false;
    grabbed=null;
  }
  return {update,hide(){group.visible=false;},get reveal(){return reveal;},get gather(){return gather;},
    target(type){return targets[shapeToFriend[type]];},
    tryGrab,dragBy,releaseGrab,
    get isGrabbed(){return !!grabbed;}};
};
